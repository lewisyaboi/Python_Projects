function throwdice(){
    var randomdice1=Math.floor(Math.random()*6 +1);
    document.getElementById("imageLocation1").setAttribute("src", "images1/d" + randomdice1 + ".png");


    var randomdice2=Math.floor(Math.random()*6 +1);
    document.getElementById("imageLocation2").setAttribute("src", "images2/d" + randomdice2 + ".png");

    var result1 = "7"
    var result2 = "11"
    if ( randomdice1 + randomdice2 == result1 )
    {
        document.getElementById('1').innerHTML = "\n\nWell Done!"
    }
    else if (randomdice1 + randomdice2 == result2)
    {
        document.getElementById('1').innerHTML = "\n\nWell Done!"
    }
    else {
        document.getElementById('1').innerHTML = "\n\nTry Again"
    }
}