﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clean_Cities
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cleanestCities = new string[5];
            string cityToCheck = "";
            int numElements = 0;
            Boolean matchFound = false;

            Console.WriteLine("Input the name of a city to see if it is one of the cleanest cities in the world");
            cityToCheck = Console.ReadLine();

            cleanestCities[0] = "Bern";
            cleanestCities[1] = "Morocco";
            cleanestCities[2] = "Minneapolis";
            cleanestCities[3] = "Singapore";
            cleanestCities[4] = "Oslo";

            numElements = cleanestCities.Length;

            for (var i = 0; i < numElements; i++)
            {
                if (cityToCheck == cleanestCities[i])
                {
                    matchFound = true;
                    Console.WriteLine("It's one of the cleanest cities");
                    break;
                }
            }

            if (matchFound == false)
            {
                Console.WriteLine("It's not one on the list!");
                Console.ReadLine();
            }

            Console.WriteLine("\nSee all of the cities");
            displayCities(cleanestCities);
        }
        public static void displayCities(string[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Array Element: " + arr[i]);
            }
            Console.ReadLine();
        }
    }
}