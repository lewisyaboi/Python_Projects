﻿using System;
using System.IO;

namespace Record_Database_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] g_strFirstName = new string[0];
            string[] g_strLastName = new string[0];
            int[] g_intScore = new int[0];

            string line = " ";
            StreamReader file = new StreamReader("testCSV.txt");

            Int32 intCount = 0;
            while ((line = file.ReadLine()) != null)
            {
                //Console.WriteLine(line);

                string[] words = line.Split(',');

                int intArrLength;
                intArrLength = g_strLastName.Length;
                Array.Resize(ref g_strFirstName, intArrLength + 1);
                Array.Resize(ref g_strLastName, intArrLength + 1);
                Array.Resize(ref g_intScore, intArrLength + 1);

                foreach (string word in words)
                {
                    g_strFirstName[intCount] = words[0];
                    g_strLastName[intCount] = words[1];
                    g_intScore[intCount] = Convert.ToInt32(words[2]);
                }
                intCount++;
            }

            for (int i = 0; i < g_strFirstName.Length; i++)
            {
                Console.WriteLine(g_strFirstName[i] + "," + g_strLastName[i] + "," + g_intScore[i]);
            }
            Console.ReadLine();
            file.Close();
        }
    }
}
