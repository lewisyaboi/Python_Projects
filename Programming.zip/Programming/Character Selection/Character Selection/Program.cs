﻿using System;
using System.IO;

namespace Character_Selection
{
    class Program
    {
        private const string Path = @"E:\Lewis Goodson\Year 2\Programming\Character Selection\Character Selection\bin\Debug\netcoreapp2.1\testCSV.txt";
        static void Main(string[] args)
        {
            string sInput;
            string sUpperInput = "";

            Console.WriteLine("Character Selection \n");

            Console.WriteLine("To Create a new character, press 'N' \nTo Load an existing character, press 'E'");
            sInput = Console.ReadLine();
            sUpperInput = sInput.ToUpper();

            if (sUpperInput == "N")
            {
                string FirstName;
                string LastName;
                string Password;
                StreamWriter objFileCSV = new System.IO.StreamWriter(Path, true);

                Console.WriteLine("Input your characters first name:");
                FirstName = Console.ReadLine();
                Console.WriteLine("Input your characters last name:");
                LastName = Console.ReadLine();
                Console.WriteLine("Input your password:");
                Password = Console.ReadLine();

                objFileCSV.WriteLine("\n" + FirstName + "," + LastName + "," + Password);

                objFileCSV.Close();
                objFileCSV.Dispose();

                Console.Clear();
                Console.WriteLine("Welcome {0}", FirstName);
            }
            else if (sUpperInput == "E")
            {
                string[] g_strFirstName = new string[0];
                string[] g_strLastName = new string[0];
                string[] g_strPassword = new string[0];

                string line = " ";
                StreamReader file = new StreamReader(Path, true);

                Int32 intCount = 0;
                while ((line = file.ReadLine()) != null)
                {
                    string[] words = line.Split(',');

                    int intArrLength;
                    intArrLength = g_strLastName.Length;
                    Array.Resize(ref g_strFirstName, intArrLength + 1);
                    Array.Resize(ref g_strLastName, intArrLength + 1);
                    Array.Resize(ref g_strPassword, intArrLength + 1);

                    foreach (string word in words)
                    {
                        g_strFirstName[intCount] = words[0];
                        g_strLastName[intCount] = words[1];
                        g_strPassword[intCount] = words[2];
                    }

                    intCount++;
                }

                for (int i = 0; i < g_strFirstName.Length; i++)
                {
                    Console.Clear();
                    Console.WriteLine("Welcome back {0}", g_strFirstName);
                }
                Console.ReadLine();
                file.Close();
            }
        }
    }
}
