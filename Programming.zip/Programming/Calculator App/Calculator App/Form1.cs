﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        float fNum1 = 0;
        float fNum2 = 0;
        float fResult = 0;

        private void txtNo1_TextChanged(object sender, EventArgs e)
        {
            fNum1 = Convert.ToInt32(txtNo1.Text);
        }

        private void txtNo2_TextChanged(object sender, EventArgs e)
        {
            fNum2 = Convert.ToInt32(txtNo2.Text);
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            fResult = fNum1 / fNum2;
            txtAns.Text = (fResult.ToString("n2"));
        }

        private void btntim_Click(object sender, EventArgs e)
        {
            fResult = fNum1 * fNum2;
            txtAns.Text = (fResult.ToString("n2"));
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            fResult = fNum1 + fNum2;
            txtAns.Text = (fResult.ToString("n2"));
        }

        private void btnmin_Click(object sender, EventArgs e)
        {
            fResult = fNum1 - fNum2;
            txtAns.Text = (fResult.ToString("n2"));
        }
    }
}
