﻿namespace Calculator_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNo1 = new System.Windows.Forms.TextBox();
            this.txtNo2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAns = new System.Windows.Forms.TextBox();
            this.btndiv = new System.Windows.Forms.Button();
            this.btntim = new System.Windows.Forms.Button();
            this.btnmin = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Number";
            // 
            // txtNo1
            // 
            this.txtNo1.Location = new System.Drawing.Point(100, 250);
            this.txtNo1.Name = "txtNo1";
            this.txtNo1.Size = new System.Drawing.Size(100, 38);
            this.txtNo1.TabIndex = 1;
            this.txtNo1.TextChanged += new System.EventHandler(this.txtNo1_TextChanged);
            // 
            // txtNo2
            // 
            this.txtNo2.Location = new System.Drawing.Point(470, 250);
            this.txtNo2.Name = "txtNo2";
            this.txtNo2.Size = new System.Drawing.Size(100, 38);
            this.txtNo2.TabIndex = 3;
            this.txtNo2.TextChanged += new System.EventHandler(this.txtNo2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(470, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Second Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(325, 525);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "Answer";
            // 
            // txtAns
            // 
            this.txtAns.Location = new System.Drawing.Point(270, 600);
            this.txtAns.Name = "txtAns";
            this.txtAns.Size = new System.Drawing.Size(219, 38);
            this.txtAns.TabIndex = 5;
            // 
            // btndiv
            // 
            this.btndiv.Location = new System.Drawing.Point(400, 350);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(100, 100);
            this.btndiv.TabIndex = 6;
            this.btndiv.Text = "/";
            this.btndiv.UseVisualStyleBackColor = true;
            this.btndiv.Click += new System.EventHandler(this.btndiv_Click);
            // 
            // btntim
            // 
            this.btntim.Location = new System.Drawing.Point(525, 350);
            this.btntim.Name = "btntim";
            this.btntim.Size = new System.Drawing.Size(100, 100);
            this.btntim.TabIndex = 7;
            this.btntim.Text = "x";
            this.btntim.UseVisualStyleBackColor = true;
            this.btntim.Click += new System.EventHandler(this.btntim_Click);
            // 
            // btnmin
            // 
            this.btnmin.Location = new System.Drawing.Point(270, 350);
            this.btnmin.Name = "btnmin";
            this.btnmin.Size = new System.Drawing.Size(100, 100);
            this.btnmin.TabIndex = 8;
            this.btnmin.Text = "-";
            this.btnmin.UseVisualStyleBackColor = true;
            this.btnmin.Click += new System.EventHandler(this.btnmin_Click);
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(144, 350);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(100, 100);
            this.btnadd.TabIndex = 9;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(300, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 39);
            this.label4.TabIndex = 10;
            this.label4.Text = "Calculator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 712);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnmin);
            this.Controls.Add(this.btntim);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.txtAns);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNo2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNo1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNo1;
        private System.Windows.Forms.TextBox txtNo2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAns;
        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btntim;
        private System.Windows.Forms.Button btnmin;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label label4;
    }
}

