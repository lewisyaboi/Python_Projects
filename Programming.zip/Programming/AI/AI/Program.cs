﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI
{
    class Program
    {
        static void Main(string[] args)
        {
            string sUser;
            DateTime date = DateTime.Now;
            DateTime time = DateTime.Now;
            string sContinue;

            do
            {
                Console.WriteLine("Input: \n");
                sUser = Console.ReadLine();
                Console.WriteLine("");

                if (sUser.Contains("weather") == true)
                {
                    Console.WriteLine("The weather is cloudy today.");
                }
                if (sUser.Contains("time") == true)
                {
                    Console.WriteLine("The time is {0}.", time);
                }
                if (sUser.Contains("date") == true)
                {
                    Console.WriteLine("The date is {0}.", date);
                }

                Console.WriteLine("\nWould you like to ask another question: ");
                sContinue = Console.ReadLine();
                Console.Clear();
            } while (sContinue == "yes");

        }
    }
}
