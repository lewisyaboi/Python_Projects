﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Split_Function_Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            string sUser;

            Console.WriteLine("Input: ");
            sUser = Console.ReadLine();

            string[] words = sUser.Split(',');
            foreach (string comma in words)
            {
                string word1 = words[0];
                string word2 = words[1];
                string word3 = words[2];
            }

            Console.WriteLine("\n{0}", words[0]);
            Console.WriteLine("\n{0}", words[1]);
            Console.WriteLine("\n{0}", words[2]);
            Console.ReadLine();
        }
    }
}
