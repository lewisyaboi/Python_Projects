﻿using System;
using System.IO;

namespace Database_Template
{
    class Program
    {
        private const string Path = @"E:\Lewis Goodson\Year 2\Programming\Record Database Example\Record Database Example\bin\Debug\netcoreapp2.1\testCSV.txt";

        static void Main(string[] args)
        {
            StreamWriter objFileNewLines = new System.IO.StreamWriter("test.txt");
            string PlayerName = "";

            Console.WriteLine("Enter your name");
            PlayerName = Console.ReadLine();

            objFileNewLines.WriteLine("Writes a string");
            objFileNewLines.WriteLine(PlayerName);
            objFileNewLines.Close();
            objFileNewLines.Dispose();

            string FirstName;
            string LastName;
            string ID;
            StreamWriter objFileCSV = new System.IO.StreamWriter(Path, true);

            Console.WriteLine("Input your first name:");
            FirstName = Console.ReadLine();
            Console.WriteLine("Input your last name:");
            LastName = Console.ReadLine();
            Console.WriteLine("Input your highscore:");
            ID = Console.ReadLine();

            objFileCSV.WriteLine("\n" + FirstName + "," + LastName + "," + ID);

            objFileCSV.Close();
            objFileCSV.Dispose();
        }
    }
}
