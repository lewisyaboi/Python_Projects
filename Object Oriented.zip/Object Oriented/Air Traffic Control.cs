﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors_and_Overloaders
{
    class Student
    {
        private double SubjectOne;
        private double SubjectTwo;
        string StudentName;
        public Student()
        {
            this.SubjectOne = 80;
        }
        // This declares the default of the variable to '80'.
        public Student(double SubjectOne)
        {
            this.SubjectOne = SubjectOne;
        }
        public Student(string StudentName, double SubjectOne, double SubjectTwo)
        {
            this.SubjectOne = SubjectOne;
            this.SubjectTwo = SubjectTwo;
            this.StudentName = StudentName;
        }
        // This allows the 3 variables to be redeclared as a new Number or Name.
        public double GetSubjectOneMarks()
        {
            return this.SubjectOne;
        }
        // This allows the main program to get the variable from the class when using 'GetSubjectOneMarks'.
        public double GetSubjectTwoMarks()
        {
            return this.SubjectTwo;
        }
        // This allows the main program to get the variable from the class when using 'GetSubjectTwoMarks'.
        public string GetStudentName()
        {
            return this.StudentName;
        }
        // This allows the main program to get the variable from the class when using 'GetStudentName'.
    }
}
