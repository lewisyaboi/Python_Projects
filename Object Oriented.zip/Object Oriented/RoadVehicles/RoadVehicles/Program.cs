﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadVehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            float fAccelerate;

            Motorcycle v = new Motorcycle();

            do
            {
                Console.WriteLine("Accelerator (Uses 1,5,10): ");
                fAccelerate = float.Parse(Console.ReadLine());
                if (fAccelerate == 10)
                {
                    v.Accelerate(10);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 0mph"
                }
                if (fAccelerate == -10)
                {
                    v.Decelerate(10);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 25mph"
                }
                if (fAccelerate == 5)
                {
                    v.Accelerate(5);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 0mph"
                }
                if (fAccelerate == -5)
                {
                    v.Decelerate(5);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 25mph"
                }
                if (fAccelerate == 1)
                {
                    v.Accelerate(1);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 0mph"
                }
                if (fAccelerate == -1)
                {
                    v.Decelerate(1);
                    Console.WriteLine("Speed: {0}mph", v.Speed);    // Outputs "Speed 25mph"
                }
            } while (v.Speed >= 1);
            if (v.Speed == 0)
            {
                Console.WriteLine("The car has stopped");
            }
            else
            {
                Console.WriteLine("The car is in reverse");
            }

            Console.ReadLine();
        }
    }
}
