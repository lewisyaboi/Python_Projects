﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
namespace DelegateS
{
    class Address
    {
        private string _city;

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        public Address()
        {
            this._city = "Aberdeen";
        }
        public Address (string city)
        {
            this._city = city;
        }

        public string AssignCityAddress (string city)
        {
            this._city = city;
            return _city;
        }







    }
}
