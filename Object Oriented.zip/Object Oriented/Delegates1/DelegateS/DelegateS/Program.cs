﻿using System;

public delegate void NameDelegate(string msg);

namespace DelegateS
{
    class Program
    {
        static void Main(string[] args)
        {

            Person per = new Person("Fabius", "Maximus");
            NameDelegate nDelegate = new NameDelegate(per.ShowFirstName);
            nDelegate("Call 1: ");

            nDelegate = new NameDelegate(per.ShowSecondName);
            nDelegate("Call 2: ");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

        }
    }
}
