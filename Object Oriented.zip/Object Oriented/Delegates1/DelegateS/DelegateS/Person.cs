﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelegateS
{
    public delegate string AssignAddress(string msg);
    class Person
    {
        private string _firstName;
        private string _secondName;

        public Person (string firstName , string secondName)
        {
            this._firstName = firstName;
            this._secondName = secondName;
        }
        public void ShowFirstName(string msg)
        {


            Console.WriteLine(msg + this._firstName);
        }
        public void ShowSecondName(string msg)
        {
            Address newAddr = new Address();
            AssignAddress addrCity = new AssignAddress(newAddr.AssignCityAddress);
            Console.WriteLine(msg + this._secondName +  " lives in " + "" + newAddr.City);
        }


    }
}
