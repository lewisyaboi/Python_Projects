﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class
{
    class Puppy : Dog
    {
        public override string sound(int SoundTimes)
        {
            if (SoundTimes == 1)
            {
                return "Yaps! once.";
            }
            else
            {
                return "Yaps" + " " + SoundTimes + " times";
            }
        }
    }
}
