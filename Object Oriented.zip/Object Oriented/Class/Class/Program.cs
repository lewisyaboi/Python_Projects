﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Dog myDog = new Dog();
            Dog yourDog = new Dog();
            Puppy myPuppy = new Puppy();

            myDog.Name = "Fido";
            Console.WriteLine("My dog is called " + myDog.Name);
            yourDog.Name = "Fang";
            Console.WriteLine("Your dog is called " + yourDog.Name);
            Console.WriteLine("Your dog {0}", myDog.sound(1));
            myDog.jump(3);

            myPuppy.Name = "Little Fido";
            Console.WriteLine("My puppy is called " + myPuppy.Name);
            myPuppy.sound(3);
            myPuppy.jump(5);

            Console.WriteLine("Please enter to finish.");
            Console.ReadLine();
        }
    }
}
