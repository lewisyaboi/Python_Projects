﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class
{
    class Dog
    {
        private string name;

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
            
        }

        public void jump(int JumpTimes)
        {
            for (int i = 1; i <= JumpTimes; i++)
            {
                Console.WriteLine("Jumps all over you.");
            }
        }

        public virtual string sound(int SoundTimes)
        {
            if (SoundTimes == 1)
            {
                return "Barks! once.";
            }
            else
            {
                return "Barks" + " " + SoundTimes + " times";
            }
        }
    }
}
