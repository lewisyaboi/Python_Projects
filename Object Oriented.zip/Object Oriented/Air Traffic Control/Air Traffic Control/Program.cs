using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Air_Traffic_Control
{
    class Program
    {
        static void Main(string[] args)
        {
            Plane s1 = new Plane("London, Luton", 76, 90);
            Plane s2 = new Plane("London, Luton", 88, 60);
            Console.WriteLine("One");
            Console.WriteLine("Subject One Marks: {0}", s1.GetLatitude());
            Console.WriteLine();
            Console.WriteLine("Second");
            Console.WriteLine("Subject One Marks: {0}", s2.GetLongitude());
            Console.WriteLine();
            Console.ReadKey();
            
           
        }
    }
}
