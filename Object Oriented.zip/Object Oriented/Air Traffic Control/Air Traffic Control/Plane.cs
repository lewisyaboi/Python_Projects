﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Air_Traffic_Control
{
    class Plane
    {
        private double Latitude;
        private double Longitude;
        string AirportName;

        public Plane(double Latitude)
        {
            this.Latitude = Latitude;
        }
        


        public Plane(string AirportName, double Latitude, double Longitude)
        {
            this.Latitude = Latitude;
            this.Longitude = Longitude;
            this.AirportName = AirportName;
        }
        
        public double GetLatitude()
        {
            return this.Latitude;
        }
        
        public double GetLongitude()
        {
            return this.Longitude;
        }
        
        public string GetAirportName()
        {
            return this.AirportName;
        }

    }
}
