﻿using System;

namespace BankBalance
{
    class Program
    {
        static void Main(string[] args)
        {
        
        }
    }
}
