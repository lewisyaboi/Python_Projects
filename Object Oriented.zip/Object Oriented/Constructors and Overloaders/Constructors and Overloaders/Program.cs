using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors_and_Overloaders
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            Student s2 = new Student(90);
            Student s3 = new Student("Amit",88,60);
            Console.WriteLine("One");
            Console.WriteLine("Subject One Marks: {0}", s1.GetSubjectOneMarks());
            Console.WriteLine();
            Console.WriteLine("Second");
            Console.WriteLine("Subject One Marks: {0}", s2.GetSubjectOneMarks());
            Console.WriteLine();
            Console.WriteLine("Third");
            Console.WriteLine("Student name: {0}", s3.GetStudentName());
            Console.WriteLine("Subject One Marks: {0}", s3.GetSubjectOneMarks());
            Console.WriteLine("Subject Two Marks: {0}", s3.GetSubjectTwoMarks());
            Console.ReadKey();

            
        }
    }
}
