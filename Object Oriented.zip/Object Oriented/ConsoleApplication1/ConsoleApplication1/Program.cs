﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
    {

        // first structure defined  
        // with public modifier 
        public struct Address
        {

            // data member of Address structure 
            public string City;
            public string State;
        }


        // Another structure  
        struct Person
        {

            // data member of Person structure 
            public string Name;
            public int Age;

            // Nesting of Address structure 
            // by creating A1 of type Address 
            public Address A1;
        }

        class Geeks
        {

            // Main method 
            static void Main(string[] args)
            {

                // Declare p1 of type Person 
                Person p1;

                // Assigning values to the variables 
                p1.Name = "Raman";
                p1.Age = 12;

                // Assigning values to the nested 
                // structure data members 
                p1.A1.City = "ABC_City";
                p1.A1.State = "XYZ_State";

                Console.WriteLine("Values Stored in p1");
                Console.WriteLine("Name: " + p1.Name);
                Console.WriteLine("Age: " + p1.Age);
                Console.WriteLine("City: " + p1.A1.City);
                Console.WriteLine("State: " + p1.A1.State);
                Console.ReadLine();

            Person p2;

            // Assigning values to the variables 
            p2.Name = "Person";
            p2.Age = 23;

            // Assigning values to the nested 
            // structure data members 
            p2.A1.City = "DEF_City";
            p2.A1.State = "WUV_State";

            Console.WriteLine("Values Stored in p2");
            Console.WriteLine("Name: " + p2.Name);
            Console.WriteLine("Age: " + p2.Age);
            Console.WriteLine("City: " + p2.A1.City);
            Console.WriteLine("State: " + p2.A1.State);
            Console.ReadLine();
        }
        }
    }